import java. util.Scanner;
public class Palin
{
    int num,revnum;
    Scanner sc=new Scanner(System.in);
    Palin()
    {
        num=0;
        revnum=0;
    }

    void accept()
    {
        System.out.println( "Enter a number") ;
        num=sc.nextInt();
    }

    int reverse( int y)
    {
        if(y>0)
        {
            revnum =revnum * 10 + (y%10);
            return reverse(y/10);
        }
        else
        {
            return revnum;
        }
    }

    void check()
    {
        if( num==reverse(num))
        {
            System.out.println(num+" is palindrome number") ;
        }
        else
        {
            System.out.println(num +" is not a palindrome number") ;
        }
    }

    public static void main()
    {
        Palin ob1=new Palin();
        ob1.accept() ;
        ob1.check() ;
    }
}