public class smithno
{
    public static int sod(int a)
    {
        int sum=0;
        while(a!=0)
        {
            int d =a%10;
            sum=sum+d;
            a=a/10;
        }
        return sum;
    }

    public static int sodpf(int a)
    {
        int sum=0;
        for(int i =2;i<=a;i++)
        {
            if(a%i==0)
            {
                sum+=sod(i   );
                a=a/i;
            }
            else
                i++;
        }
        return sum;
    }

    public static void main(int a)
    {
        if(sod(a)==sodpf(a))
            System.out.println("Smith No.");
        else
            System.out.println("Not a Smith No.");
    }
}
