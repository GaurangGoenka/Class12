import java.util.*;
public class TheString{
    int wordCount;
    int cons;
    String str;
    int len;
    public void input(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter string maximum of 100 characters with only one blank space between the words ");
        str =sc.nextLine();
        len = str.length();
        if(len<101 && str.indexOf(' ') != -1 && str.indexOf(' ') == str.lastIndexOf(' '))
            System.out.println("The string contains exactly one space and 100 character.");
        else 
            System.out.println("Error"); 
    }

    public void fre()
    {
        cons=0;
        wordCount =1;
        String x = str.toLowerCase();
        for(int i=0;i<len;i++)
        {
            if(str.charAt(i)==' ' && str.charAt(i+1)!= ' ')
                wordCount=wordCount+1;
            if("aeiouAEIOU".indexOf(str.charAt(i))==-1)
            {
                System.out.println(x.charAt(i));
                cons=cons+1;
            }
        }
    }

    public void display(){
        System.out.println("Orginal String = " + str);
        System.out.println("Words = " + wordCount );
        System.out.println("Consonant = " + cons );
    }

    public static void main(){
        TheString ob = new TheString();
        ob.input();
        ob.fre();
        ob.display();
    }
}