import java.util.Scanner;

public class Disarium
{
    int n ;
    public Disarium()
    {
     n=0;   
    }
    public void getnum()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Number");
        n=sc.nextInt();
    }
    public int Sumdigitspower()
    {
      int sum=0;
      int cpy=n;
      int length=(cpy+"").length();
      while(cpy!=0)
      {
          int d=cpy%10;
          sum+=Math.pow(d,length);
          length--;
          cpy/=10;
      }
      return sum;
    }
    public void isDisarium()
    {
        if(n==Sumdigitspower())
          System.out.println( n+" is a Disarium Number");
        else
          System.out.println("It is not a Disarium Number");
    }
    public static void main()
    {
      Disarium obj= new Disarium();
      obj.getnum();
      obj.isDisarium();
        
    }
}