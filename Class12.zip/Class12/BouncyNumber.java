public class BouncyNumber
{
    public static void main(int a)
    {
        int asc=0;
        int des=0;
        while(a>9)
        {
            int d =a%10;
            int d2=(a%100)/10;
            if(d>d2)
            des++;
            if(d<d2)
            asc++;
            a=a/10;
        }
        if(asc>0&&des>0)
        {
            System.out.println("A Bouncy Number");
        }
        else
        {
            System.out.println( "Not A Bouncy Number");
        }
    }
}