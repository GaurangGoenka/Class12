public class SymmetricMatrix
{
    public static void main(int n)
    {
        int arr[][]=new int[n][n];
        for(int i =0;i<n;i++)
        {
            for(int j =0;j<n;j++)  
            {
                arr[i][j]= (int)(Math.random()*100+1);  
            }
        }
        for(int i =0;i<n;i++)
        {
            for(int j =0;j<n;j++)  
            {
                System.out.print(arr[i][j]+"\t");  
            }
            System.out.println();
        }
        System.out.println();
        System.out.println();
        int check=0;
        for(int i =0;i<n;i++)
        {
            for(int j =n;j>=0;j--)  
            {
                if(arr[i][j]==arr[j][i])
                check++;
            }
        }
        if(check==9)
        System.out.println("Symmetric Matrix");
        else
        System.out.println("Not a Symmetric Matrix");
    }
}