
import java.util.Arrays;
public class PendulumArray 
{
    public static void main(int arr[])
    {
        int l=arr.length;
        Arrays.sort(arr);
        int mid =l/2;
        int brr[]=new int[l];
        brr[mid]=arr[0];
        System.out.println("Original array: ");
        for(int i =0;i<arr.length;i++)
        {
            System.out.print(arr[i]+",");
        }
        System.out.println();
        int left = mid - 1;
        int right = mid + 1;        
        for (int i = 1; i < arr.length; i++) 
        {
            if (i % 2 != 0) 
            {
                brr[right++] = arr[i];
            } else 
            {
                brr[left--] = arr[i];
            }
        }
        System.out.println("Pendulum Arrangement" );
        for(int i =0;i<brr.length;i++)
        {
            System.out.print(brr[i]+",");
        }
    }
}