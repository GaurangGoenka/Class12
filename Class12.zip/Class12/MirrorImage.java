public class MirrorImage
{
    public static void main()
    {
        int arr[][]=new int[5][6];
        for(int i =0;i<5;i++)
        {
            for(int j =0;j<6;j++)  
            {
                arr[i][j]= (int)(Math.random()*100+1);  
            }
        }
        for(int i =0;i<5;i++)
        {
            for(int j =0;j<6;j++)  
            {
                System.out.print(arr[i][j]+"\t");  
            }
            System.out.println();
        }
        System.out.println();
        System.out.println();
        for(int i =0;i<5;i++)
        {
            for(int j =5;j>=0;j--)  
            {
                System.out.print(arr[i][j]+"\t");  
            }
            System.out.println();
        }
    }
}
/*public class initailsing_random

{
public static void main()
{
int arr[][]=new int [5][6];
for(int i=0;i<5;i++)
{
for(int j=0;j<6;j++)
{
arr[i][j]=(int) (Math.random()*100+1);
System.out.print(arr[i][j]+"\t");
}
System.out.println();
}
}
}**/
