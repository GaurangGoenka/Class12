 
public class BinarySearching
{
  public static void main(int arr[],int a)
  {
   int e=arr.length-1;
   int s=0;
   int mid=0;
   int c=0;
   while(s<=e)
   {
      mid = (e+s)/2;
      if(arr[mid]==a)
      {
       System.out.println("Element found at"+mid);
       c++;
       break;
      }
      else if(a>arr[mid])
      s=mid+1;
      else
      e=mid-1;
   }
   if(c==0)
            System.out.println("Element not found");
  }
}

