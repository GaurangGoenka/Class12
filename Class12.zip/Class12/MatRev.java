import java.util.Scanner;
public class MatRev
{
    int arr[][],m,n;
    Scanner sc=new Scanner(System.in);
    MatRev(int mm,int nn)
    {
        m=mm;
        n=nn;
        arr=new int[m][n];
    }

    void fillarray()
    {
        System.out.println("ENTER ELEMENTS IN ARRAY");
        for(int i=0;i< m;i++)
        {
            for(int j=0 ;j< n;j++)
            {
                arr[i][j]=sc.nextInt();
            }
        }
    }

    int reverse(int x)
    {
        int rev=0, rem=0;
        while(x!=0)
        {
            rem=x% 10;
            rev=rev*10 + rem;
            x=x/ 10;
        }
        return rev;
    }

    void revMat(MatRev P)
    {
        for(int i=0;i< m;i++)
        {
            for(int j=0 ;j< n;j++)
            {
                arr[i][j]=reverse(P.arr[i][j]);
            }
        }
    }

    void show()
    {
        for(int i=0;i< m;i++)
        {
            for(int j=0 ;j< n;j++)
            {
                System.out.print(arr[i][j] + "\t");
            }
            System.out.println();
        }
    }

    public static void main()
    {
        Scanner sc1=new Scanner(System.in);
        System.out.println("ENTER NUMBER OF ROWS OF MATRIX");
        int row=sc1.nextInt();
        System.out.println("ENTER NUMBER OF COLUMNS OF MATRIX");
        int col=sc1.nextInt();
        MatRev ob1 = new MatRev(row,col);
        MatRev ob2=new MatRev(row,col);
        ob1.fillarray();
        System.out.println("Original Array");
        ob1.show();
        ob2.revMat(ob1);
        System.out.println(" Reverse array");
        ob2.show(); 
    }
}