import java.util.Scanner;

public class Shift {
    Scanner sc = new Scanner(System.in);
    int mat[][];
    int m, n;

    Shift(int mm, int nn) {
        m = mm;
        n = nn;
        mat = new int[m][n];
    }

    void input() {
        System.out.println("Enter elements of array");
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                mat[i][j] = sc.nextInt();
            }
        }
    }

    void display() {
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                System.out.print(mat[i][j] + " ");
            }
            System.out.println();
        }
    }

    void cyclic(Shift P) {
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                if (i == 0) {
                    mat[m - 1][j] = P.mat[0][j];
                } else {
                    mat[i - 1][j] = P.mat[i][j];
                }
            }
        }
    }

    public static void main() {
        Scanner sc1 = new Scanner(System.in);
        System.out.println("ENTER THE NUMBER OF ROWS");
        int r = sc1.nextInt();
        System.out.println("ENTER THE NUMBER OF COLUMNS");
        int c = sc1.nextInt();
        Shift ob1 = new Shift(r,c);
        Shift ob2 = new Shift(r,c);
        ob1.input();
        ob2.cyclic(ob1);
        ob1.display();
        ob2.display();
    }
}
