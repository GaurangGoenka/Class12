import java.util.Scanner;

public class Admission {
    Scanner sc = new Scanner(System.in);
    int Adno[];

    Admission() {
        Adno = new int[100];
    }

    void fillArray() {
        System.out.println("Enter 100 elements in ascending order");
        for (int i = 0; i < 100; i++) {
            Adno[i] = sc.nextInt();
        }
    }

    int binSearch(int l, int u, int v) {
        int m = (l + u) / 2;
        if (Adno[m] == v) {
            return 1;
        } else if (l > u) {
            return -1;
        } else if (v > Adno[m]) {
            return binSearch(m + 1, u, v);
        } else {
            return binSearch(l, m - 1, v);
        }
    }

    public static void main() {
        Scanner sc1 = new Scanner(System.in);
        Admission ob1 = new Admission();
        ob1.fillArray();
        System.out.println("Enter value to be searched");
        int v = sc1.nextInt();
        int p = ob1.binSearch(0, ob1.Adno.length - 1, v);
        if (p == -1) {
            System.out.println(v + " not found in the array");
        } else {
            System.out.println(v + " is found in the array");
        }
    }
}
