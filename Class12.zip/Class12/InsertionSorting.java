class InsertionSorting
{
    public static void main(int arr[])
    {
        int l=arr.length;
        for(int i=1;i<l;i++)
        {
            for(int j=i;j>=0;j++)
            {
                if(arr[j]<arr[j-1])
                {
                    int t=arr[j];
                    arr[j]=arr[j-1];
                    arr[j-1]=t;
                }
                else
                break;
            }
        }
        for(int i=0;i<arr.length;i++)
        {
            System.out.print(arr[i]+",");
        }
    }
}
