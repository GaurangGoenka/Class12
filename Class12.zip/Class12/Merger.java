import java.util.*;
class Merger{
    int n1, n2;
    long mergNum ;
    public Merger()
    {
        n1 = 0;
        n2 = 0;
    }
    public Merger(int x , int y)
    {
        n1 = x;
        n2 = y;
    }
    public void readNum(){
        Scanner sc = new Scanner ( System.in);
        System.out.println("Enter the 2 integer " );
        n1 = sc.nextInt();
         n2 = sc.nextInt();
    }
    public void joinNum(){
        String x = ""+n2;
        int l = x.length();
        int c = n1 * ((int)Math.pow(10,l));
        mergNum = c + n2;
    }
    public void show(){
        System.out.println("Original Number are = " + n1 +  " and " + n2);
        System.out.println("Merger = " + mergNum);  
    }
    public static void main(){
        Merger ob = new Merger();
        ob.readNum();
        ob.joinNum();
        ob.show();
        System.out.println();
        Merger obb = new Merger();
        obb.joinNum();
        obb.show();
        System.out.println();
        Merger obbb = new Merger(78,98);
        obbb.joinNum();
        obbb.show();
    }
}