import java.util.Scanner;
public class Dates
{
    int dd;
    String mm;
    int yy;
    int nod;
    public void setDate(int d,String m,int y)
    {
        dd=d;
        mm=m;
        yy=y;
    }
    public void showDate()
    {
        System.out.println(dd+"/"+mm+"/"+yy);
    }
    public boolean isleap(int yy)
    {
        if(yy%4==0&&yy%100!=0||yy%400==0)
            return true;
        else 
            return false;
    }
    public void addDate(int day)//add date
    {
        nod=day;
        while(nod>365)//for year change
        {
            nod=nod-365;
            yy++;
        }
        int[] arr = {31,(isleap(yy) ? 29 : 28), 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
        String brr[]={"January","February","March","April","May","June","July","August","September","October","November","December"};
        int sum=0;
        int m=0;
        for(int i=0;i<brr.length;i++)//to take out current month
        {
            if(mm.equals(brr[i]))
                m=i+1;
        }
        int nodl=arr[m]-dd;//no. of days left in current month
        if(nod<=nodl)//if in the same month
        {
            dd=dd+nod;
        }
        else
        {
            nod=nod-nodl;//subtracting no. of days left and increasing month by 1
            m=m+1;
            for(int i =m;i<12;i++)
            {            
                if(nod<=sum+arr[i])
                {     
                    mm=brr[1];
                    dd=Math.abs(sum-nod);
                    break;
                }         
                sum+=arr[i]; 
            }
        }
    }
    public static void main(String args[])
    {
        Scanner sc = new  Scanner(System.in);
        String brr[]={"January","February","March","April","May","June","July","August","September","October","November","December"};
        System.out.println("Enter Date");
        Dates dt1= new Dates();
        int d=sc.nextInt();
        String m =brr[sc.nextInt()-1];
        int y=sc.nextInt();
        System.out.println("Enter Number of Days to be Added");
        int n=sc.nextInt();
        dt1.setDate(d,m,y);
        dt1.showDate();
        dt1.addDate(n);
        dt1.showDate();
    }
}
