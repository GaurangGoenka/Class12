import java.util.*;
public class ArmNum
{
    int n,l;
    ArmNum(int nn)
    {
        n=nn;
        l=Integer.toString(n).length();
    }

    int sum_pow(int i)
    {
        if(i==0)
        {
            return 0;
        }
        else
        {
            return (int)Math.pow(i%10,l) + sum_pow(i/10);
        }
    }

    void isArmstrong()
    {
        if(sum_pow(n)==n)
        {
            System.out.println(n + " is an Armstrong number");
        }
        else
        {
            System.out.println(n + "is not an Armstrong number");
        }
    }

    public static void main()
    {
        Scanner sc=new Scanner(System.in); 
        System.out.println("ENTER THE NUMBER"); 
        int num=sc.nextInt(); 
        ArmNum ob1=new ArmNum(num); 
        ob1.isArmstrong(); 
    }
}