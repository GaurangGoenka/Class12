import java.util.*;
public class ProductofMatrices{
    public static void main (){
        int arr[][] = {{3,2,1,5},{9,1,3,0}};
        int arr2[][] = {{2, 9, 0},{1, 3, 5},{2, 4, 7},{8,1,5}};
        int pro[][] = new int[arr.length][arr2[0].length];
         if (arr[0].length != arr2.length) {
            System.out.println("Error");
        }
        else {   
        for(int i=0;i<arr.length;i++)
        {
            for(int j=0;j<arr2[0].length;j++)
            {
                 for (int k = 0; k < arr[0].length; k++) 
                 {
                        pro[i][j] = pro[i][j] + arr[i][k] * arr2[k][j];
                }
            }
        }
         for(int i=0;i<arr.length;i++)
        {
            for(int j=0;j<arr2[0].length;j++)
            {
                System.out.print(pro[i][j] + " ");
            }
            System.out.println();
        }
    }
    }
}