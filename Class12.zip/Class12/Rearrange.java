import java.util.Scanner;

public class Rearrange
{
    String wrd;
    String newwrd;
    Rearrange()
    {
        wrd="";
        newwrd="";
    }

    void readword()
    {
        Scanner sc= new Scanner(System.in);
        System.out.print("Enter Word : ");
        wrd= (sc.next()).toUpperCase(); 

    }

    void freq_vow_con()
    {
        int vc=0,cc=0;
        for(int i =0;i< wrd.length();i++)
        {
            if("AEIOUaeiou".indexOf(wrd.charAt(i))!=-1)
                vc++;
            else
                cc++;
        }
        System.out.println("Vowels Count : "+vc);
        System.out.println("Consonants Count : "+cc);
    }

    void arrange()
    {
        String  vowel="";
        String  cont="";
        for(int i =0;i< wrd.length();i++)
        {
            if("AEIOUaeiou".indexOf(wrd.charAt(i))!=-1)
                vowel+=wrd.charAt(i);
            else
                cont+=wrd.charAt(i);
        }
        newwrd=vowel+""+cont;
    }
    
    void display()
    {
        System.out.println("Original Word : "+wrd);
        System.out.println("New Word : "+newwrd);
    }
    
    public static void main()
    {
        Rearrange obj= new Rearrange();
        obj.readword();
        obj.freq_vow_con();
        obj.arrange();
        obj.display();
    }
}