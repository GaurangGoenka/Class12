public class GoldBachNo
{
    static boolean checkoddprime(int a)
    {
        int f=0;
        for(int i =1;i<=a;i++)
        {
            if(a%i==0)
                f++;
            }
        if(f==2&& a%2!=0)
            return true;
        else
            return false;
    }
    public static void main(int n)
    {
        for(int i =1;i<n;i++)
        {
            if(checkoddprime(i)&&i==n-i||checkoddprime(i)&&checkoddprime(n-i))
            {
              System.out.println("Goldbach No");  
              System.out.println(i +" + "+ (n-i) + " = "+ n);
            }
        }
    }
    
}