import java .util.Scanner;
public class SwapSort
{
    String wrd,swapwrd,sortwrd;
    int len;
    Scanner sc=new Scanner(System.in) ;
    SwapSort()
    {
        swapwrd="" ;
        sortwrd=" ";
        len=0;
        wrd="";
    }

    void readword()
    {
        System.out.println("Enter  word in Upper case");
        wrd=sc.next() ;
        len=wrd.length();
        wrd=wrd.toUpperCase();
    }

    void swapchar()
    {
        /*add last character of word to swapwrd*/
        swapwrd=swapwrd+wrd.charAt(len-1);
        /*add characters between first and last character of word to swapwrd*/
        swapwrd=swapwrd+ wrd.substring(1,len-1);
        /*add first character to swapwrd*/
        swapwrd=swapwrd + wrd.charAt(0);
    }

    void sortword()
    {
        char ch1;
        for(char ch='A' ;ch<='Z';ch++)
        {
            for(int i=0 ;i < len;i++)
            {
                ch1=wrd.charAt(i);
                if(ch1==ch)
                {
                    sortwrd += ch1;
                }
            }
        }
    }

    void display()
    {
        System.out.println("Original  word = " + wrd);
        System.out.println("Swapped  word = " + swapwrd);
        System.out.println("Sorted  word = " + sortwrd);
    }

    public static void main()
    {
        SwapSort ob1=new SwapSort();
        ob1.readword() ;
        ob1.swapchar();
        ob1.sortword();
        ob1.display();
    }
}