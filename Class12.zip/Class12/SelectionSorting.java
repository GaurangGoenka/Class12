 
public class SelectionSorting
{
    public static void main(int arr[])
    {
        for(int i =0;i<arr.length;i++)
        {
            int min=i;
            for(int j =i+1;j<arr.length ;j++)
            {
                if(arr[min]<arr[j])
                {
                    min=j; 
                }
            }
            int t =arr[min];
            arr[min]=arr[i];
            arr[i]=t;
        }
        for(int i =0;i<arr.length;i++)
        {
            System.out.println(arr[i]);
        }
    }
}
