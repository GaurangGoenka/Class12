import java.util.Scanner;
public class Swap_row_array
{
    public static void main(int n) 
    {
        int arr[][]=new int[n][n];
        for(int i =0;i<n;i++)
        {
            for(int j =0;j<n;j++)  
            {
                arr[i][j]= (int)(Math.random()*100+1);  
            }
        }
        for(int i =0;i<n;i++)
        {
            for(int j =0;j<n;j++)  
            {
                System.out.print(arr[i][j]+"\t");  
            }
            System.out.println();
        }
        System.out.println();
        System.out.println();
        for(int i =0;i<arr.length-1;i++)
        {
            for (int j = 0; j < arr.length; j++) 
            {
                int t = arr[i][j];
                arr[i][j] = arr[i+1][j];
                arr[i+1][j] = t;
            }
        }
        for (int i = 0; i < 4; i++) 
        {
            for (int j = 0; j < 4; j++) 
            {
                System.out.print(arr[i][j] + "        ");
            }
            System.out.println();
        }
    }
}