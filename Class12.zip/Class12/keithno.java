public class keithno
{
    public static void main(int n)
    {
        int m =n;
        String a=n+"";
        int arr[]=new int[a.length()];
        int sum=0;
        for(int i =arr.length-1;i>=0;i--)
        {
            arr[i]=n%10;
            n/=10;
        }
        while(sum<m)
        {
            sum=arr[0];
            for(int i =0;i<arr.length-1;i++)
            {
              arr[i]=arr[i+1];
              sum=sum+arr[i];
            }
            arr[arr.length-1]=sum;
        }
        if(sum==m)
        System.out.println("Keith Number");
        else
        System.out.println(" Not a Keith Number");
    }
}