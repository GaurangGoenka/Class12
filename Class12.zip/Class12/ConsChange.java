import java.util.Scanner;

public class ConsChange {
    String word;
    int len;
    Scanner sc = new Scanner(System.in);

    ConsChange() {
        len = 0;
        word = "";
    }

    void readword() {
        System.out.println("Enter word in Lowercase");
        word = sc.next();
        len = word.length();
    }

    void shiftcons() {
        String consonants = "", vowels = "", sortedWord = "";
        char ch = ' ';
        for (int i = 0; i < len; i++) {
            ch = word.charAt(i);
            if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
                vowels += ch;
            } else {
                consonants += ch;
            }
        }
        sortedWord = consonants + vowels;
        System.out.println("Sorted Word = " + sortedWord);
        word = sortedWord;
    }

    void changeword() {
        char ch = ' ';
        String newWd = "";
        for (int i = 0; i < len; i++) {
            ch = word.charAt(i);
            if (ch != 'a' && ch != 'e' && ch != 'i' && ch != 'o' && ch != 'u') 
            {
                newWd += Character.toUpperCase(ch);
            } 
            else 
            {
                newWd += ch;
            }
        }
        System.out.println("Changed word = " + newWd);
    }

    void show() {
        System.out.println("Original word = " + word);
        shiftcons();
        changeword();
    }

    public static void main() {
        ConsChange ob1 = new ConsChange();
        ob1.readword();
        ob1.show();
    }
}
