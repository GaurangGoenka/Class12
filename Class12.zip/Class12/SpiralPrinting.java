class SpiralPrinting
{
    public static void main()
    {
        int a[][]={{1,2,3},{4,5,6},{7,8,9}};
        int rowBegin=0;
        int rowEnd=a.length-1;
        int colBegin=0;
        int colEnd=a.length-1;
        while(rowBegin<=rowEnd && colBegin<=colEnd)
        {
            for(int j=colBegin;j<=colEnd;j++)
                System.out.print(a[rowBegin][j]);
            rowBegin++;

            for(int j=rowBegin;j<=rowEnd;j++)
                System.out.print(a[j][colEnd]);
            colEnd--;

            if(rowBegin<=rowEnd)
                for(int j=colEnd;j>=colBegin;j--)
                    System.out.print(a[rowEnd][j]);
            rowEnd--;

            if(colBegin<=colEnd)
                for(int j=rowEnd;j>=rowBegin;j--)
                    System.out.print(a[j][colBegin]);
            colBegin++;
        }
    }
}