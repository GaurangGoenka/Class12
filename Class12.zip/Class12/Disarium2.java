import java.util.Scanner;
public class Disarium2
{
    int num,size;
    Disarium2(int nn)
    {
        num=nn;
        size=0;
    }
    void countDigits()
    {
        int temp=num;
        while(temp>0)
        {
            temp=temp/10;
            size++;
        }
    }
    int sumofDigits(int n,int p)
    {
        if(n==0)
        {
            return 0;
        }
        else
        {
            return (int)Math.pow((n%10),p) +sumofDigits((n/10),(p-1));
        }
    }