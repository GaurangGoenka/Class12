import java.util.*;
public class BubbleSorting
{
    public static void main(int arr[])
    {
        for(int i =0;i<arr.length-1;i++)
        {
            for(int j =0;j<arr.length -1-i;j++)
            {
                if(arr[j]>arr[j+1])
                {
                    int t =arr[j+1];
                    arr[j+1]=arr[j];
                    arr[j]=t;
                }
            }
        }
        for(int i =0;i<arr.length;i++)
        {
            System.out.println(arr[i]);
        }
    }
}
