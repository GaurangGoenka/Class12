public class SpiralFilling
{
    public static void main(int n)
    {
        int arr[][] = new int[n][n];
        int rowstart=0;
        int rowend=arr.length-1;
        int colstart=0;
        int colend=arr.length-1;
        int z=1;
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<n;j++)    
            {
                System.out.print(arr[i][j]+",");
            }
            System.out.println();
        }
        while(rowstart<=rowend&&colstart<=colend)
        {
            for(int i=colstart;i<=colend;i++)
            {
                arr[rowstart][i]=z++;   
            }
            rowstart++;
            for(int i = rowstart;i<=rowend;i++)
            {
                arr[i][colend]=z++;
            }
            colend--;
            for(int i =colend;i>=colstart;i--)
            {
                arr[rowend][i]=z++;
            }
            rowend--;
            for(int i=rowend;i>=rowstart;i--)
            {
                arr[i][colstart]=z++;
            }
            colstart++;
        }        
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<n;j++)    
            {
                System.out.print(arr[i][j]+"    ");
            }
            System.out.println();
            System.out.println();
        }
    }
}