import java.util.Scanner;
public class EqMat 
{    
    int a[][];
    int m;
    int n;
    Scanner sc = new Scanner(System.in);
    EqMat(int mm, int nn) 
    {
        m = mm;
        n = nn;
        a = new int[m][n];
    }

    void readarray() 
    {
        System.out.println("enter " + (m * n) + " elements");
        for (int i = 0; i < m; i++) 
        {
            for (int j = 0; j < n; j++) 
            {
                a[i][j] = sc.nextInt();
            }
        }
    }

    int check(EqMat P, EqMat Q) 
    {
        for (int i = 0; i < P.m; i++) 
        {
            for (int j = 0; j < P.n; j++) 
            {
                if (P.a[i][j] != Q.a[i][j]) 
                {
                    return 0;
                }
            }
        }
        return 1;
    }

    void print() 
    {
        for (int i = 0; i < m; i++) 
        {
            for (int j = 0; j < n; j++) 
            {
                System.out.print(a[i][j] + " ");
            }
            System.out.println();
        }
    }

    public static void main(String[] args) 
    {
        Scanner sc1 = new Scanner(System.in);
        System.out.println("ENTER NUMBER OF ROWS OF MATRIX");
        int row = sc1.nextInt();
        System.out.println("ENTER NUMBER OF COLUMNS OF MATRIX");
        int col = sc1.nextInt();

        EqMat ob1 = new EqMat(row, col);
        EqMat ob2 = new EqMat(row, col);

        System.out.println("enter nos for the 1st Matrix");
        ob1.readarray();
        System.out.println("enter nos for the 2nd Matrix");
        ob2.readarray();

        if (ob1.check(ob1, ob2) == 1) {
            System.out.println("Equal Matrix");
            ob1.print();
            ob2.print();
        } 
        else 
        {
            System.out.println("not equal");
        }
    }
}
